//document.getElementById('myEntry').textContent = "You are " + str(localStorage.getItem('current_status')) + "!";
